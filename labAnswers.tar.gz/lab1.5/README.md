## Instruction to run and compile
    - the library need to install
        -- pip install pycryptodome
    - run the program
        -- python labAnswer.py
    - results
        -- the result sample output will be produced on the terminal    
## Important Notice
    - some function might be slow when running due to large amount of computation